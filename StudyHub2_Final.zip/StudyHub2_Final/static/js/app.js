(() => {
  "use strict";

  const $ = (id) => document.getElementById(id);
  const STORAGE_KEY = "studyhub_v2_data";
  const MIGRATION_KEY = "studyhub_v2_migrated";
  const FOCUS_SECONDS = 50 * 60;
  const BREAK_SECONDS = 10 * 60;

  let appData = { assignments: [], flashcards: [] };
  let stats = {};
  let timerMode = "focus";
  let remainingSeconds = FOCUS_SECONDS;
  let timerRunning = false;
  let timerDeadline = null;
  let timerInterval = null;
  let toastTimeout = null;

  function notify(message) {
    const toast = $("toast");
    if (!toast) return;
    toast.textContent = message;
    toast.classList.add("show");
    clearTimeout(toastTimeout);
    toastTimeout = setTimeout(() => toast.classList.remove("show"), 2600);
  }

  async function api(url, options = {}) {
    const response = await fetch(url, {
      ...options,
      headers: { "Content-Type": "application/json", ...(options.headers || {}) }
    });
    const payload = await response.json().catch(() => ({}));
    if (!response.ok) throw new Error(payload.error || "Something went wrong.");
    return payload;
  }

  async function migrateLegacyData() {
    if (localStorage.getItem(MIGRATION_KEY) === "true") return;
    let old = {};
    try { old = JSON.parse(localStorage.getItem(STORAGE_KEY) || "{}") || {}; }
    catch (error) { console.warn("Legacy StudyHub data could not be parsed.", error); }

    const hasLegacyData = Number(old.studyMinutes) > 0 ||
      Number(old.sessions) > 0 ||
      (Array.isArray(old.assignments) && old.assignments.length > 0) ||
      (Array.isArray(old.flashcards) && old.flashcards.length > 0);

    // The backend marks migration complete only after a successful import.
    const result = await api("/api/migrate", {
      method: "POST",
      body: JSON.stringify({
        studyMinutes: Number(old.studyMinutes) || 0,
        sessions: Number(old.sessions) || 0,
        assignments: Array.isArray(old.assignments) ? old.assignments : [],
        flashcards: Array.isArray(old.flashcards) ? old.flashcards : []
      })
    });
    if (result.already_migrated || hasLegacyData || !hasLegacyData) {
      localStorage.setItem(MIGRATION_KEY, "true");
    }
  }

  async function loadData() {
    const [assignments, flashcards, dashboard] = await Promise.all([
      api("/api/assignments"), api("/api/flashcards"), api("/api/stats")
    ]);
    appData.assignments = assignments;
    appData.flashcards = flashcards;
    stats = dashboard;
    renderAssignments();
    renderFlashcards();
    renderStats();
  }

  function renderStats() {
    $("study-hours").textContent = ((stats.total_study_minutes || 0) / 60).toFixed(1);
    $("assignment-count").textContent =
      Math.max(0, (stats.assignments?.total || 0) - (stats.assignments?.completed || 0));
    $("completed-sessions").textContent = stats.focus_sessions || 0;
    $("flashcard-count").textContent = stats.flashcards || 0;
    $("assignment-total").textContent = `${appData.assignments.length} task${appData.assignments.length === 1 ? "" : "s"}`;
    $("flashcard-total").textContent = `${appData.flashcards.length} card${appData.flashcards.length === 1 ? "" : "s"}`;
  }

  function escapeText(value) {
    return String(value ?? "").replace(/[&<>"']/g, char => ({
      "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;"
    })[char]);
  }

  function renderAssignments() {
    const container = $("assignment-list");
    const filter = $("assignment-filter")?.value || "all";
    const tasks = appData.assignments.filter(task => {
      if (filter === "pending") return !task.completed;
      if (filter === "completed") return Boolean(task.completed);
      return true;
    });
    if (!tasks.length) {
      const message = appData.assignments.length
        ? "No assignments match this filter."
        : "Add an assignment above to get started.";
      container.innerHTML = `<div class="empty-state"><span>✦</span><strong>${appData.assignments.length ? "All clear" : "Nothing on your list yet"}</strong><p>${message}</p></div>`;
      return;
    }
    container.innerHTML = tasks.map(task => {
      const priorityClass = `priority-${String(task.priority || "medium").toLowerCase()}`;
      const due = task.deadline ? new Date(`${task.deadline}T00:00:00`) : null;
      const today = new Date(); today.setHours(0,0,0,0);
      const overdue = due && due < today && !task.completed;
      const dueText = task.deadline
        ? `${overdue ? "Overdue · " : "Due · "}${due.toLocaleDateString(undefined, {day:"numeric", month:"short", year:"numeric"})}`
        : "No due date";
      return `<div class="assignment-row">
        <input class="task-check" type="checkbox" aria-label="Mark ${escapeText(task.title)} complete" data-complete="${task.id}" ${task.completed ? "checked" : ""}>
        <div class="task-main"><div class="task-title ${task.completed ? "done" : ""}">${escapeText(task.title)}</div>
          <div class="task-meta"><span class="priority-label ${priorityClass}">${escapeText(task.priority)}</span><span class="task-deadline ${overdue ? "overdue" : ""}">${escapeText(dueText)}</span></div>
        </div>
        <button class="small-action complete-label" type="button" data-toggle="${task.id}">${task.completed ? "Undo" : "Complete"}</button>
        <button class="small-action delete" type="button" data-delete-assignment="${task.id}" aria-label="Delete assignment">Delete</button>
      </div>`;
    }).join("");
  }

  function renderFlashcards() {
    const container = $("flashcard-list");
    if (!appData.flashcards.length) {
      container.innerHTML = `<div class="empty-state"><span>✧</span><strong>Your deck is waiting</strong><p>Create your first flashcard above.</p></div>`;
      return;
    }
    container.innerHTML = appData.flashcards.map(card => `
      <article class="flashcard">
        <div class="flashcard-question">${escapeText(card.question)}</div>
        <p class="flashcard-answer" id="answer-${card.id}" hidden>${escapeText(card.answer)}</p>
        <div class="flashcard-actions">
          <button class="small-action" type="button" data-reveal="${card.id}">Reveal answer</button>
          <button class="small-action delete" type="button" data-delete-card="${card.id}">Delete</button>
        </div>
      </article>`).join("");
  }

  async function refresh() {
    await loadData();
  }

  async function createAssignment(event) {
    event.preventDefault();
    const title = $("assignment-title").value.trim();
    if (!title) return;
    try {
      await api("/api/assignments", {
        method: "POST",
        body: JSON.stringify({
          title,
          deadline: $("assignment-deadline").value || null,
          priority: $("assignment-priority").value
        })
      });
      $("assignment-form").reset();
      await refresh();
      notify("Assignment added to your list.");
    } catch (error) { notify(error.message); }
  }

  async function setAssignmentComplete(id, completed) {
    try {
      await api(`/api/assignments/${id}`, {
        method: "PATCH", body: JSON.stringify({ completed })
      });
      await refresh();
      notify(completed ? "Assignment completed. Nice work!" : "Assignment moved back to pending.");
    } catch (error) { notify(error.message); }
  }

  async function removeAssignment(id) {
    if (!window.confirm("Delete this assignment?")) return;
    try {
      await api(`/api/assignments/${id}`, { method: "DELETE" });
      await refresh();
      notify("Assignment deleted.");
    } catch (error) { notify(error.message); }
  }

  async function createFlashcard(event) {
    event.preventDefault();
    const question = $("flashcard-question").value.trim();
    const answer = $("flashcard-answer").value.trim();
    if (!question || !answer) return;
    try {
      await api("/api/flashcards", {
        method: "POST", body: JSON.stringify({ question, answer })
      });
      $("flashcard-form").reset();
      await refresh();
      notify("Flashcard created.");
    } catch (error) { notify(error.message); }
  }

  async function removeFlashcard(id) {
    if (!window.confirm("Delete this flashcard?")) return;
    try {
      await api(`/api/flashcards/${id}`, { method: "DELETE" });
      await refresh();
      notify("Flashcard deleted.");
    } catch (error) { notify(error.message); }
  }

  function setTimerMode(mode) {
    if (timerRunning) pauseTimer();
    timerMode = mode;
    remainingSeconds = mode === "focus" ? FOCUS_SECONDS : BREAK_SECONDS;
    $("focus-mode").classList.toggle("selected", mode === "focus");
    $("break-mode").classList.toggle("selected", mode === "break");
    $("start-btn").innerHTML = mode === "focus" ? "▶ <span>Start focus</span>" : "▶ <span>Start break</span>";
    $("timer-status").textContent = mode === "focus" ? "READY WHEN YOU ARE" : "TIME TO RECHARGE";
    updateTimerDisplay();
  }

  function updateTimerDisplay() {
    const minutes = Math.floor(remainingSeconds / 60);
    const seconds = remainingSeconds % 60;
    $("timer").textContent = `${String(minutes).padStart(2,"0")}:${String(seconds).padStart(2,"0")}`;
    const total = timerMode === "focus" ? FOCUS_SECONDS : BREAK_SECONDS;
    const progress = Math.max(0, Math.min(1, 1 - remainingSeconds / total));
    $("timer-ring").style.background = `conic-gradient(var(--purple) ${progress * 360}deg, #49395f ${progress * 360}deg 360deg)`;
  }

  function pauseTimer() {
    timerRunning = false;
    timerDeadline = null;
    clearInterval(timerInterval);
    timerInterval = null;
    $("start-btn").innerHTML = "▶ <span>Resume</span>";
    $("timer-status").textContent = "PAUSED";
  }

  async function finishFocusSession() {
    try {
      await api("/api/sessions", {
        method: "POST", body: JSON.stringify({ duration_minutes: 50 })
      });
      await refresh();
      notify("Focus session saved. Great work!");
    } catch (error) {
      notify(`Session finished, but could not save: ${error.message}`);
    }
  }

  function completeTimerPhase() {
    timerRunning = false;
    clearInterval(timerInterval);
    timerInterval = null;
    timerDeadline = null;
    if (timerMode === "focus") {
      finishFocusSession();
      $("timer-status").textContent = "FOCUS COMPLETE · BREAK TIME";
      notify("50 minutes completed. Take your 10-minute break.");
      setTimerMode("break");
    } else {
      $("timer-status").textContent = "BREAK COMPLETE · READY TO FOCUS";
      notify("Break complete. Ready for another focus session?");
      setTimerMode("focus");
    }
  }

  function tickTimer() {
    if (!timerRunning || !timerDeadline) return;
    remainingSeconds = Math.max(0, Math.ceil((timerDeadline - Date.now()) / 1000));
    updateTimerDisplay();
    if (remainingSeconds <= 0) completeTimerPhase();
  }

  function startTimer() {
    if (timerRunning) return;
    timerRunning = true;
    timerDeadline = Date.now() + remainingSeconds * 1000;
    $("start-btn").innerHTML = "Ⅱ <span>Pause</span>";
    $("timer-status").textContent = timerMode === "focus" ? "FOCUS SESSION IN PROGRESS" : "BREAK IN PROGRESS";
    clearInterval(timerInterval);
    timerInterval = setInterval(tickTimer, 250);
  }

  function resetTimer() {
    timerRunning = false;
    timerDeadline = null;
    clearInterval(timerInterval);
    timerInterval = null;
    remainingSeconds = timerMode === "focus" ? FOCUS_SECONDS : BREAK_SECONDS;
    $("start-btn").innerHTML = timerMode === "focus" ? "▶ <span>Start focus</span>" : "▶ <span>Start break</span>";
    $("timer-status").textContent = "READY WHEN YOU ARE";
    updateTimerDisplay();
  }

  function attachEvents() {
    $("assignment-form").addEventListener("submit", createAssignment);
    $("flashcard-form").addEventListener("submit", createFlashcard);
    $("assignment-filter").addEventListener("change", renderAssignments);
    $("start-btn").addEventListener("click", () => timerRunning ? pauseTimer() : startTimer());
    $("reset-btn").addEventListener("click", resetTimer);
    $("focus-mode").addEventListener("click", () => setTimerMode("focus"));
    $("break-mode").addEventListener("click", () => setTimerMode("break"));

    $("assignment-list").addEventListener("change", event => {
      const checkbox = event.target.closest("[data-complete]");
      if (checkbox) setAssignmentComplete(Number(checkbox.dataset.complete), checkbox.checked);
    });
    $("assignment-list").addEventListener("click", event => {
      const toggle = event.target.closest("[data-toggle]");
      const remove = event.target.closest("[data-delete-assignment]");
      if (toggle) {
        const task = appData.assignments.find(item => item.id === Number(toggle.dataset.toggle));
        if (task) setAssignmentComplete(task.id, !Boolean(task.completed));
      }
      if (remove) removeAssignment(Number(remove.dataset.deleteAssignment));
    });
    $("flashcard-list").addEventListener("click", event => {
      const reveal = event.target.closest("[data-reveal]");
      const remove = event.target.closest("[data-delete-card]");
      if (reveal) {
        const answer = $(`answer-${reveal.dataset.reveal}`);
        answer.hidden = !answer.hidden;
        reveal.textContent = answer.hidden ? "Reveal answer" : "Hide answer";
      }
      if (remove) removeFlashcard(Number(remove.dataset.deleteCard));
    });

    document.querySelectorAll(".nav-link").forEach(link => {
      link.addEventListener("click", () => {
        document.querySelectorAll(".nav-link").forEach(item => item.classList.remove("active"));
        link.classList.add("active");
      });
    });
  }

  async function initialize() {
    attachEvents();
    updateTimerDisplay();
    try {
      await api("/api/health");
      await migrateLegacyData();
      await loadData();
    } catch (error) {
      console.error("StudyHub initialization failed:", error);
      notify(`Could not connect to StudyHub: ${error.message}`);
    }
  }

  document.addEventListener("DOMContentLoaded", initialize);
})();
