STUDYHUB 2.0 — FINAL PROJECT

1. Keep this folder structure:
   StudyHub2_Final/
     app.py
     studyhub.db (created automatically on first run)
     templates/index.html
     static/css/style.css
     static/js/app.js

2. Install Flask (once):
   py -m pip install flask

3. Run from this folder:
   py app.py

4. Open:
   http://127.0.0.1:5000

IMPORTANT:
- Stop your old Flask server with Ctrl+C before starting this version.
- Back up your existing StudyHub2/studyhub.db before replacing any files.
- To preserve your existing assignments, flashcards and study history, copy your current studyhub.db into this folder BEFORE the first launch.
- The first run creates any missing tables and keeps existing SQLite data.
- Do not delete the old project until you have tested this version.
