from flask import Flask, render_template, request, jsonify
import sqlite3
from pathlib import Path
from datetime import date, datetime, timedelta

app = Flask(__name__)
DATABASE = Path(__file__).with_name("studyhub.db")


def get_db_connection():
    connection = sqlite3.connect(DATABASE, timeout=10)
    connection.row_factory = sqlite3.Row
    connection.execute("PRAGMA foreign_keys = ON")
    return connection


def initialize_database():
    with get_db_connection() as connection:
        connection.executescript("""
            CREATE TABLE IF NOT EXISTS study_sessions (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                duration_minutes INTEGER NOT NULL CHECK(duration_minutes > 0),
                completed_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
            );

            CREATE TABLE IF NOT EXISTS assignments (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                title TEXT NOT NULL,
                deadline TEXT,
                priority TEXT NOT NULL DEFAULT 'Medium',
                completed INTEGER NOT NULL DEFAULT 0
            );

            CREATE TABLE IF NOT EXISTS flashcards (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                question TEXT NOT NULL,
                answer TEXT NOT NULL
            );

            CREATE TABLE IF NOT EXISTS migration_metadata (
                key TEXT PRIMARY KEY,
                value TEXT
            );
        """)


@app.get("/")
def home():
    return render_template("index.html")


@app.get("/api/health")
def health():
    return jsonify({"status": "ok"})


@app.route("/api/migrate", methods=["POST"])
def migrate_data():
    data = request.get_json(silent=True)
    if not isinstance(data, dict):
        return jsonify({"error": "Invalid migration data"}), 400

    try:
        study_minutes = max(0, int(float(data.get("studyMinutes", 0))))
        sessions = max(0, int(data.get("sessions", 0)))
    except (TypeError, ValueError, OverflowError):
        return jsonify({"error": "Invalid study statistics"}), 400

    assignments = data.get("assignments", [])
    flashcards = data.get("flashcards", [])
    if not isinstance(assignments, list) or not isinstance(flashcards, list):
        return jsonify({"error": "Invalid assignment or flashcard data"}), 400

    with get_db_connection() as connection:
        already = connection.execute(
            "SELECT 1 FROM migration_metadata WHERE key = 'localStorage_migrated'"
        ).fetchone()
        if already:
            return jsonify({"message": "Data has already been migrated",
                            "already_migrated": True})

        for item in assignments:
            if not isinstance(item, dict):
                continue
            title = item.get("title")
            if not isinstance(title, str) or not title.strip():
                continue
            deadline = item.get("deadline")
            if not isinstance(deadline, str):
                deadline = None
            priority = item.get("priority", "Medium")
            if priority not in ("Low", "Medium", "High"):
                priority = "Medium"
            completed = int(item.get("completed") is True or item.get("completed") == 1)
            connection.execute(
                "INSERT INTO assignments(title, deadline, priority, completed) VALUES (?, ?, ?, ?)",
                (title.strip()[:200], deadline, priority, completed)
            )

        for item in flashcards:
            if not isinstance(item, dict):
                continue
            question, answer = item.get("question"), item.get("answer")
            if isinstance(question, str) and question.strip() and isinstance(answer, str) and answer.strip():
                connection.execute(
                    "INSERT INTO flashcards(question, answer) VALUES (?, ?)",
                    (question.strip()[:1000], answer.strip()[:3000])
                )

        # Preserve both the legacy total and its session count. The old
        # localStorage format did not retain each session's individual length,
        # so distribute the total minutes evenly across the recorded count.
        legacy_count = sessions if sessions > 0 else (1 if study_minutes > 0 else 0)
        if legacy_count:
            base_minutes, remainder = divmod(study_minutes, legacy_count)
            for index in range(legacy_count):
                minutes = base_minutes + (1 if index < remainder else 0)
                if minutes > 0:
                    connection.execute(
                        "INSERT INTO study_sessions(duration_minutes) VALUES (?)",
                        (minutes,)
                    )

        connection.execute(
            "INSERT INTO migration_metadata(key, value) VALUES (?, ?)",
            ("localStorage_migrated", "true")
        )

    return jsonify({
        "message": "Migration completed",
        "assignments_imported": len(assignments),
        "flashcards_imported": len(flashcards),
        "study_minutes_imported": study_minutes,
        "legacy_session_count": sessions
    })


@app.get("/api/assignments")
def get_assignments():
    with get_db_connection() as connection:
        rows = connection.execute("""
            SELECT * FROM assignments
            ORDER BY completed ASC,
                     CASE priority WHEN 'High' THEN 1 WHEN 'Medium' THEN 2 ELSE 3 END,
                     CASE WHEN deadline IS NULL OR deadline = '' THEN 1 ELSE 0 END,
                     deadline ASC, id DESC
        """).fetchall()
    return jsonify([dict(row) for row in rows])


@app.post("/api/assignments")
def add_assignment():
    data = request.get_json(silent=True) or {}
    title = data.get("title")
    deadline = data.get("deadline") or None
    priority = data.get("priority", "Medium")
    if not isinstance(title, str) or not title.strip():
        return jsonify({"error": "Assignment title is required"}), 400
    if priority not in ("Low", "Medium", "High"):
        return jsonify({"error": "Invalid priority"}), 400
    if deadline is not None:
        try:
            datetime.strptime(deadline, "%Y-%m-%d")
        except (TypeError, ValueError):
            return jsonify({"error": "Deadline must be a valid date"}), 400
    with get_db_connection() as connection:
        cursor = connection.execute(
            "INSERT INTO assignments(title, deadline, priority) VALUES (?, ?, ?)",
            (title.strip()[:200], deadline, priority)
        )
        new_id = cursor.lastrowid
    return jsonify({"message": "Assignment added", "id": new_id}), 201


@app.patch("/api/assignments/<int:assignment_id>")
def update_assignment(assignment_id):
    data = request.get_json(silent=True) or {}
    completed = data.get("completed")
    if type(completed) is not bool:
        return jsonify({"error": "Completed must be true or false"}), 400
    with get_db_connection() as connection:
        cursor = connection.execute(
            "UPDATE assignments SET completed = ? WHERE id = ?",
            (int(completed), assignment_id)
        )
    if cursor.rowcount == 0:
        return jsonify({"error": "Assignment not found"}), 404
    return jsonify({"message": "Assignment updated"})


@app.delete("/api/assignments/<int:assignment_id>")
def delete_assignment(assignment_id):
    with get_db_connection() as connection:
        cursor = connection.execute("DELETE FROM assignments WHERE id = ?", (assignment_id,))
    if cursor.rowcount == 0:
        return jsonify({"error": "Assignment not found"}), 404
    return jsonify({"message": "Assignment deleted"})


@app.get("/api/flashcards")
def get_flashcards():
    with get_db_connection() as connection:
        rows = connection.execute("SELECT * FROM flashcards ORDER BY id DESC").fetchall()
    return jsonify([dict(row) for row in rows])


@app.post("/api/flashcards")
def add_flashcard():
    data = request.get_json(silent=True) or {}
    question, answer = data.get("question"), data.get("answer")
    if not isinstance(question, str) or not question.strip():
        return jsonify({"error": "Question is required"}), 400
    if not isinstance(answer, str) or not answer.strip():
        return jsonify({"error": "Answer is required"}), 400
    with get_db_connection() as connection:
        cursor = connection.execute(
            "INSERT INTO flashcards(question, answer) VALUES (?, ?)",
            (question.strip()[:1000], answer.strip()[:3000])
        )
        new_id = cursor.lastrowid
    return jsonify({"message": "Flashcard added", "id": new_id}), 201


@app.delete("/api/flashcards/<int:flashcard_id>")
def delete_flashcard(flashcard_id):
    with get_db_connection() as connection:
        cursor = connection.execute("DELETE FROM flashcards WHERE id = ?", (flashcard_id,))
    if cursor.rowcount == 0:
        return jsonify({"error": "Flashcard not found"}), 404
    return jsonify({"message": "Flashcard deleted"})


@app.post("/api/sessions")
def add_session():
    data = request.get_json(silent=True) or {}
    duration = data.get("duration_minutes")
    if type(duration) is not int or not 1 <= duration <= 1440:
        return jsonify({"error": "Session duration must be between 1 and 1440 minutes"}), 400
    with get_db_connection() as connection:
        cursor = connection.execute(
            "INSERT INTO study_sessions(duration_minutes) VALUES (?)", (duration,)
        )
        session_id = cursor.lastrowid
    return jsonify({"message": "Focus session saved", "id": session_id}), 201


@app.get("/api/stats")
def get_stats():
    today = date.today()
    with get_db_connection() as connection:
        assignment_stats = connection.execute("""
            SELECT COUNT(*) AS total,
                   COALESCE(SUM(completed), 0) AS completed
            FROM assignments
        """).fetchone()
        flashcards = connection.execute("SELECT COUNT(*) AS total FROM flashcards").fetchone()
        sessions = connection.execute("""
            SELECT COUNT(*) AS total_sessions,
                   COALESCE(SUM(duration_minutes), 0) AS total_minutes
            FROM study_sessions
        """).fetchone()
        daily = connection.execute("""
            SELECT date(completed_at) AS day, SUM(duration_minutes) AS minutes
            FROM study_sessions
            GROUP BY date(completed_at)
            ORDER BY day DESC LIMIT 60
        """).fetchall()

    studied_days = {row["day"] for row in daily if row["day"]}
    streak = 0
    cursor_day = today
    if cursor_day.isoformat() not in studied_days:
        cursor_day -= timedelta(days=1)
    while cursor_day.isoformat() in studied_days:
        streak += 1
        cursor_day -= timedelta(days=1)

    return jsonify({
        "assignments": {"total": assignment_stats["total"],
                        "completed": assignment_stats["completed"]},
        "flashcards": flashcards["total"],
        "focus_sessions": sessions["total_sessions"],
        "total_study_minutes": sessions["total_minutes"],
        "streak": streak,
        "daily_minutes": [{"day": row["day"], "minutes": row["minutes"]} for row in reversed(daily)]
    })


if __name__ == "__main__":
    initialize_database()
    app.run(debug=True)
